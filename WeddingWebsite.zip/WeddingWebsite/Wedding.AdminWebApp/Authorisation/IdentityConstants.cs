﻿namespace Wedding.AdminWebApp.Authorisation
{
    public static class IdentityConstants
    {
        public const string Password = "Qwer!@#12345";
    }
}