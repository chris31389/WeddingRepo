﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Wedding.AdminWebApp.Authorisation
{
    public class ApplicationUser : IdentityUser
    {
    }
}