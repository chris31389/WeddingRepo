﻿namespace Wedding.AdminWebApp.Controllers
{
    public class InviteeWdto
    {
        public string Fullname { get; set; }

        public bool IsAdult { get; set; }

    }
}