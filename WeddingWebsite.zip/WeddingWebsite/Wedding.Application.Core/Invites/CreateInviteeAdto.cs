﻿namespace Wedding.Application.Core.Invites
{
    public class CreateInviteeAdto
    {
        public string Fullname { get; set; }

        public bool IsAdult { get; set; }
    }
}