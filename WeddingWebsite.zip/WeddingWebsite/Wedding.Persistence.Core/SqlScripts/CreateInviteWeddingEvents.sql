CREATE TABLE InviteWeddingEvent(
	Id uniqueidentifier,
	InviteId uniqueidentifier,
	WeddingEventId uniqueidentifier
)
