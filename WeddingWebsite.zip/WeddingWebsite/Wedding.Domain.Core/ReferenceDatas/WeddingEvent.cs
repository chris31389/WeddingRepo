﻿namespace Wedding.Domain.Core.ReferenceDatas
{
    public class WeddingEvent : ReferenceData
    {
        protected WeddingEvent() : base()
        {
        }

        public WeddingEvent(string value) : base(value)
        {
        }
    }
}