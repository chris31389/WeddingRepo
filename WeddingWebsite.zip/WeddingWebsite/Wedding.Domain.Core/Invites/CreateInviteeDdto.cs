﻿namespace Wedding.Domain.Core.Invites
{
    public class CreateInviteeDdto
    {
        public string Fullname { get; set; }

        public bool IsAdult { get; set; }
    }
}