﻿using Wedding.Persistence.Contexts;

namespace Wedding.Persistence.Tests
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
            using (var context = new WeddingDbContext())
            {
                
            }
        }
    }
}
