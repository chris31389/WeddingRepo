﻿namespace Wedding.WebApp.Controllers
{
    public class LoginViewModel
    {
        public string UserName { get; set; }
    }
}