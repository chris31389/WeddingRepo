(function () {
    'use strict';
    angular.module("app")
    .component('myfooter', {
        templateUrl: 'app/components/footer/footer.template.html'
    });
}());