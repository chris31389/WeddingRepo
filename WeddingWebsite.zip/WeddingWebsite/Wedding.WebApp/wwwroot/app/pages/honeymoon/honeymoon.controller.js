﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HoneymoonController', honeymoonController);

    // honeymoonController.$inject = [];

    function honeymoonController() {
        /* jshint validthis: true */
        var vm = this;
    }
})();
