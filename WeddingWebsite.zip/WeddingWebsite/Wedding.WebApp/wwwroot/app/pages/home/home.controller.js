﻿(function () {
    "use strict";

    angular
        .module("app")
        .controller("HomeController", homeController);

    function homeController() {
        var vm = this;

    }
})();
