﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Wedding.WebApp.Authorisation
{
    public class ApplicationUser : IdentityUser
    {
    }
}