﻿namespace Wedding.WebApp.Authorisation
{
    public static class IdentityConstants
    {
        public const string Password = "Qwer!@#12345";
    }
}