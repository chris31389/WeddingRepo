﻿namespace Wedding.Common.Core
{
    public interface IConfigurationManager
    {
        string GetSetting(string settingName);
    }
}